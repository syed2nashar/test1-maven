#!/bin/bash
chmod +x /home/ec2-user/my-app-1.0-SNAPSHOT.jar
chmod +x /home/ec2-user/start_server.sh
chmod +x /home/ec2-user/stop_server.sh
